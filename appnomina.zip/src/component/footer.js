import React, { Component }  from "react";

class Footer extends Component {
    render() {
        return (
            <div class="copyright py-4 text-center text-white">
                <div class="container"><small>Copyright &copy; MisiónTIC Grupo 13 Equipo 9</small></div>
            </div>
        )
    }
}
export default Footer;